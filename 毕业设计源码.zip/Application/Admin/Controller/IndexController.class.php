<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends SessionController {
    public function index(){
        $this->display();
    }
}
<?php
namespace Admin\Controller;
use Think\Controller;
class LstController extends SessionController {
    public function lst(){
        $user=M('User');
        $count = $user->count();
        $Page = new \Think\Page($count,1);
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();
        $list = $user->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('data',$list);
        $this->assign('page',$show);
        $this->display(); 
        
       
       
    }

    public function all(){
        $content=M('Content');
        $id=I('get.id');
        $arr['uid']=$id;
        session('i',$id);
        $hb=$content->where($arr)->join('system_user ON system_content.uid = system_user.id')->select();
        $this->assign('hb',$hb);
        $this->display('all');
    }


    public function delc(){
        $content=M('Content');
        $id=I('get.id');
        $i=session('i');
        if($content->delete($id)){
            $this->success('删除留言成功！', U("Admin/lst/all/id/$i"));
        }else{
            $this->error('删除失败！');
        }
        
    }


    public function del(){
        $user=D('User');
        $id=I('get.id');
        if($user->relation(true)->delete($id)){
            $this->success('删除成功',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }

}
<?php
namespace Admin\Controller;
use Think\Controller;
class ManagerController extends SessionController {
    public function lst(){
        $manager=M('Manager');
        $managers=$manager->select();
        $this->assign('lst',$managers);
        $this->display('lst');
    }

    public function add(){
        $manager=D('Manager');
        if(IS_POST){
            $data['mname']=I('mname');
            $data['mpwd']=I('mpwd');
            if($manager->create()){
                    if($manager->add()){
                        $this->success('添加客服经理成功', U('lst'));
                    }else{
                        $this->error('添加客服经理失败');
                    }
                    return;
            }else{
                $this->error($manager->geterror());
            }
            
        }
        $this->display();
    }

    

    public function edit(){
        $manager=D('Manager');
        $data = $manager->find(I('get.id'));
        $this->assign('data',$data);
        if(IS_POST){
            $ndata['mid']=I('mid');
            $ndata['mname']=I('mname');
            $ndata['mpwd']=I('mpwd');
            if($manager->create($ndata)){
                if($manager->save()){
                    $this->success('修改成功',U('lst'));
                }else{
                    $this->error('修改失败');
                }
            }else{
                $this->error($manager->geterror());
            }
            return;
        }
    
        $this->display();
        
    }

    public function del(){
        $manager=M('Manager');
        $mid=I('get.mid');
        if($manager->delete($mid)){
            $this->success('删除成功',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }






}
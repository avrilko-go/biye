<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends SessionController {
    public function edit(){
        $admin=D('Admin');
        if(IS_POST){
            $ndata['name']=I('name');
            $ndata['aid']=1;
            $ndata['pwd']=md5(I('pwd'));
            $ndata['rpwd']=md5(I('rpwd'));
            if($admin->create($ndata)){
                if($admin->save()){
                    $this->success('修改成功',U('Admin/Index/index'));
                }else{
                    $this->error('修改失败');
                }
            }else{
                $this->error($admin->geterror());
            }
            return;
        }
        $this->display();
        
    }
}
<?php
namespace Admin\Model;
use Think\Model;
class ManagerModel extends Model {
    protected $_validate = array(
       array('mname','require','客服经理名称不能为空!'), //默认情况下用正则进行验证
       array('mname','','这个名称已经存在！',0,'unique',1), // 在新增的时候验证字段是否唯一
       array('mpwd','require','密码不能为空!'),
       array('rmpwd','mpwd','两次输入的密码不一致！',0,'confirm'),
   );
}
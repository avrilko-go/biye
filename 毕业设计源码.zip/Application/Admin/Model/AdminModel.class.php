<?php
namespace Admin\Model;
use Think\Model;
class AdminModel extends Model {
    protected $_validate = array(
       array('pwd','require','密码不能为空!'), //默认情况下用正则进行验证
       array('name','require','名称不能为空!'),
       array('rpwd','pwd','两次输入的密码不一致！',0,'confirm'),
       array('pwd','require','密码不能为空!',1,'regex',4),
       array('name','require','账号不能为空!',1,'regex',4),
       array('verify','check_verify','验证码错误!',1,'callback',4),
   );

    public function login(){
    	$pwd=$this->pwd;
    	$info=$this->where(array('name'=>$this->name))->find();
    	if($info){
    		if($info['pwd'] == md5($pwd)){
    			session('id',$info['id']);
    			session('name',$info['name']);
          session('flag',1);
    			return true;
    		}else{
    			return false;
    		}
    	}else{
    		return false;
    	}
    }


    function check_verify($code, $id = ''){
    	$verify = new \Think\Verify();
    	return $verify->check($code, $id);
	}



}
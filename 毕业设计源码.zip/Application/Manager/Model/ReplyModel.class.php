<?php
namespace Manager\Model;
use Think\Model;
class ReplyModel extends Model {
    protected $_validate = array(
       array('con','require','回复内容不能为空!'), //默认情况下用正则进行验证
   );
}
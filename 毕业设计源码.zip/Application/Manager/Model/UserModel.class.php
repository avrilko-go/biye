<?php
namespace Manager\Model;
use Think\Model\RelationModel;

 //一个关联模型
class UserModel extends RelationModel{
    protected $_link = array(
        'content'=>array(
            'mapping_type'      => self::HAS_MANY,
            'foreign_key'   => 'uid',
            ),
        );


     protected $_validate = array(
       array('username','require','用户名不能为空!'), //默认情况下用正则进行验证
       array('password','require','密码不能为空!'), //默认情况下用正则进行验证
       array('tel','require','手机号不能为空!'), //默认情况下用正则进行验证
       array('email','email','email格式错误','0','regex',3),
       array('tel','isMobile','手机号码错误！','0','callback',3)
   );


     function isMobile($mobile) {
    	if (!is_numeric($mobile)) {
        	return false;
   		}
    		return preg_match('#^13[\d]{9}$|^14[5,7]{1}\d{8}$|^15[^4]{1}\d{8}$|^17[0,6,7,8]{1}\d{8}$|^18[\d]{9}$#', $mobile) ? true : false;
 	}




}
<?php
namespace Manager\Model;
use Think\Model;
class ManagerModel extends Model {
    protected $_validate = array(
       array('mpwd','require','密码不能为空!'), //默认情况下用正则进行验证
       array('mname','require','名称不能为空!'),
       array('mrpwd','mpwd','两次输入的密码不一致！',0,'confirm'),
       array('mpwd','require','密码不能为空!',1,'regex',4),
       array('mname','require','账号不能为空!',1,'regex',4),
       array('verify','check_verify','验证码错误!',1,'callback',4),
   );

    public function login(){
    	$mpwd=$this->mpwd;
    	$info=$this->where(array('mname'=>$this->mname))->find();
    	if($info){
    		if($info['pwd'] == $pwd){
    			session('mid',$info['mid']);
    			session('mname',$info['mname']);
          session('flag',2);
    			return true;
    		}else{
    			return false;
    		}
    	}else{
    		return false;
    	}
    }


    function check_verify($code, $id = ''){
    	$verify = new \Think\Verify();
    	return $verify->check($code, $id);
	}



}
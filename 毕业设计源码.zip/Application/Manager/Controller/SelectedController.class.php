<?php
namespace Manager\Controller;
use Think\Controller;
class SelectedController extends SessionController {
    public function lst(){
        $content=M('Content');
        $mid=session('mid');
        $map['gid']=$mid;
        $contents=$content->where($map)->join('system_user ON system_content.uid = system_user.id')->select();
        $count = count($contents);
        $Page = new \Think\Page($count,5);
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();
        $list = $content->where($map)->join('system_user ON system_content.uid = system_user.id')->limit($Page->firstRow.','.$Page->listRows)->order('times desc')->select();
        $this->assign('data',$list);
        $this->assign('page',$show);
        $this->display('lst'); 
        
       
       
    }

    public function reply(){
        $reply=M('Reply');
        $map['cid']=I('get.cid');
        session('cid',I('cid'));
        $i=session('i');
        $replys=$reply->join('system_content ON system_reply.ccid = system_content.cid')->join('system_user ON system_content.uid = system_user.id')->join('system_manager ON system_content.gid = system_manager.mid')->where($map)->order('rtime')->select();
        $this->assign('data',$replys);
        $this->display('reply');
        
         
    }

    public function addreply(){
        $replys=D('Reply');
        if(IS_POST){
            $mid=session('mid');
            $cid=session('cid');
            $data['con']=I('con');
            $data['rtime']=time();
            $data['ccid']=$cid;
            $data['rflag']=$mid;
            $data['hb']=1;
            if($replys->create($data)){
                if($replys->add()){
                    $this->success('发表回复成功！',U("Manager/Selected/reply/cid/$cid"));
                }else{
                    $this->error('发表回复失败');
                }
                return;
            }else{
                $this->error($replys->geterror());
            }

        }

    }


    public function rdel(){
        $reply=M('Reply');
        $cid=session('cid');
        $rid=I('get.rid');
        $i=session('i');
        if($reply->delete($rid)){
            $this->success('删除该回复成功',U("Manager/Selected/reply/cid/$cid"));
        }else{
            $this->error('删除该回复失败');
        }
    }





    public function del(){
        $content=M('Content');
        $cid=I('get.cid');
        if($content->delete($cid)){
            $this->success('删除成功！',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }

}
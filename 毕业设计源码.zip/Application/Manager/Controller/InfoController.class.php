<?php
namespace Manager\Controller;
use Think\Controller;
class InfoController extends SessionController {
    public function lst(){
        $info = M('User');
        $count = $info->count();
        $Page = new \Think\Page($count,5);
        $show = $Page->show();
        $list = $info->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('data',$list);
        $this->assign('page',$show);
        $this->display(); 
    }

    public function edit(){
        $user=D('User');
        $data = $user->find(I('get.id'));
        $this->assign('data',$data);
        if(IS_POST){
            $ndata['username']=I('username');
            $ndata['id']=I('id');
            $ndata['password']=I('password');
            $ndata['tel']=I('tel');
            $ndata['email']=I('email');
            if($user->create($ndata)){
                if($user->save()){
                    $this->success('修改信息成功',U('lst'));
                }else{
                    $this->error('修改失败');
                }
            }else{
                $this->error($user->geterror());
            }
            return;
        }
        $this->display();
        
    }

    public function del(){
        $user=D('User');
        $id=I('get.id');
        if($user->relation(true)->delete($id)){
            $this->success('删除成功',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }






}
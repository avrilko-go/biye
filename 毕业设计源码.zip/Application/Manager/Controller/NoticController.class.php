<?php
namespace Manager\Controller;
use Think\Controller;
class NoticController extends SessionController {
    public function lst(){
        $notic=M('Notic');
        $count = $notic->count();
        $Page = new \Think\Page($count,5);
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();
        $list = $notic->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('lst',$list);
        $this->assign('page',$show);
        $this->display(); 
    }


    public function add(){
        $notic=D('Notic');
        if(IS_POST){
            $data['notics']=I('notics');
            $data['time']=time();
            $data['who']=session('mname');
            if($notic->create($data)){
                    if($notic->add()){
                        $this->success('发表公告成功', U('lst'));
                    }else{
                        $this->error('发表公告失败');
                    }
                    return;
            }else{
                $this->error($notic->geterror());
            }
            
        }
        $this->display();
    }



    
    

    public function del(){
        $notic=M('Notic');
        $nid=I('get.nid');
        if($notic->delete($nid)){
            $this->success('删除成功',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }
}
<?php
namespace Manager\Controller;
use Think\Controller;
class ManagerController extends SessionController {
    public function edit(){
        $manager=D('Manager');
        if(IS_POST){
            $ndata['mname']=I('mname');
            $ndata['mid']=session('mid');
            $ndata['mpwd']=I('mpwd');
            $ndata['mrpwd']=I('mrpwd');
            if($manager->create($ndata)){
                if($manager->save()){
                    $this->success('修改成功',U('Manager/Index/index'));
                }else{
                    $this->error('修改失败');
                }
            }else{
                $this->error($manager->geterror());
            }
            return;
        }
        $this->display();
        
    }
}
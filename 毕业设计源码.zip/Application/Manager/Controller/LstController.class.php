<?php
namespace Manager\Controller;
use Think\Controller;
class LstController extends SessionController {
    public function lst(){
        $content=M('Content');
        $map['gid']=0;
        $contents=$content->where($map)->join('system_user ON system_content.uid = system_user.id')->order('times desc')->select();
        $count = count($contents);
        $Page = new \Think\Page($count,5);
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();
        $list = $content->where($map)->join('system_user ON system_content.uid = system_user.id')->order('times desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('data',$list);
        $this->assign('page',$show);
        $this->display(); 
        
       
       
    }



    public function select(){
        $content=M('Content');
        $data['gid']=I('get.mid');
        $data['cid']=I('get.cid');
        if($content->save($data)){
            $this->success('选择处理当前反馈成功，已经添加至已受理查看！',U('lst'));
        }else{
            $this->error('选择失败！');
        }
    }



    public function del(){
        $content=M('Content');
        $cid=I('get.cid');
        if($content->delete($cid)){
            $this->success('删除成功！',U('lst'));
        }else{
            $this->error('删除失败');
        }
    }

}
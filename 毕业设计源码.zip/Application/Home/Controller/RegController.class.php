<?php
namespace Home\Controller;
use Think\Controller;
class RegController extends Controller {
    public function reg(){
    	$this->display();
    }

    public function add(){
    	$user=D('User');
    	if(IS_POST){
    		$data['username']=I('username');
    		$data['password']=I('password');
    		$data['rpassword']=I('rpassword');
    		$data['tel']=I('tel');
    		$data['email']=I('email');
    		$data['utime']=time();
    		if($user->create($data)){
    			if($user->add()){
    				session(null);
    				$this->success('注册成功！' ,U('Login/index'));
    			}else{
    				$this->error('注册失败');
    			}
    		}else{
    			$this->error($user->geterror());
    		}
    	}
    }


}
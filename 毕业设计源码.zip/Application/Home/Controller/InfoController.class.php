<?php
namespace Home\Controller;
use Think\Controller;
class InfoController extends SessionController {
    public function lst(){
        $info = M('User');
        $id=session('id');
        $infos=$info->find($id);   
        $this->assign('datas',$infos);
        $this->display('lst'); 
    }

    public function edit(){
        $user=D('User');
        $data = $user->find(I('get.id'));
        $this->assign('data',$data);
        if(IS_POST){
            $ndata['username']=I('username');
            $ndata['id']=I('id');
            $ndata['password']=I('password');
            $ndata['tel']=I('tel');
            $ndata['email']=I('email');
            if($user->create($ndata)){
                if($user->save()){
                    $this->success('修改信息成功',U('lst'));
                }else{
                    $this->error('修改失败');
                }
            }else{
                $this->error($user->geterror());
            }
            return;
        }
        $this->display();
        
    }





}
<?php
namespace Home\Controller;
use Think\Controller;
class SessionController extends Controller {
    public function __construct(){
        parent::__construct();
        if(session('flag') !== 3){
            $this->error('非法操作，请先登录！',U('Login/index'));
        }
    }
        
}
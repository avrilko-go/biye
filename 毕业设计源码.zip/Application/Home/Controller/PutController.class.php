<?php
namespace Home\Controller;
use Think\Controller;
class PutController extends SessionController {
    
    public function put(){
        $content=D('Content');
        $id=session('id');
        if(IS_POST){
            $data['contents']=I('contents');
            $data['times']=time();
            $data['uid']=$id;
            $data['gid']=0;
            if($content->create($data)){
                    if($content->add()){
                        $this->success('投诉成功,可到已受理查询受理状态！', U('Put/put'));
                    }else{
                        $this->error('投诉失败！');
                    }
                    return;
            }else{
                $this->error($content->geterror());
            }
            
        }
        $this->display('put');
    }

}
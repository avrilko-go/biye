<?php
namespace Home\Controller;
use Think\Controller;
class LoginController extends Controller {
    public function index(){
        $user=D('User');
        if(IS_POST){
            $data['username']=I('username');
            $data['password']=I('password');
            $data['verify']=I('verify');
            if($user->create($data,4)){
                if($user->login()){
                    $this->success('登陆成功！',U('Index/lst'));
                }else{
                    $this->error('您的用户名或密码错误！');
                }
            }else{
                $this->error($user->geterror());
            }
            return;
        }

        if(session('flag') == 3){
            $this->error('请不要重复登录',U('Index/lst'));
        }else{
            $this->display('login');
        }

        
    }

    public function verify(){
        $Verify =     new \Think\Verify();
        $Verify->fontSize = 30;
        $Verify->length   = 4;
        $Verify->entry();
    }

}
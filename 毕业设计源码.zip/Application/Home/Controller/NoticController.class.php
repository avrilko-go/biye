<?php
namespace Home\Controller;
use Think\Controller;
class NoticController extends SessionController {
    public function lst(){
        $notic=M('Notic');
        $count = $notic->count();
        $Page = new \Think\Page($count,5);
        $Page->setConfig('prev','上一页');
        $Page->setConfig('next','下一页');
        $show = $Page->show();
        $list = $notic->order('time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
        $this->assign('lst',$list);
        $this->assign('page',$show);
        $this->display(); 
    }

}

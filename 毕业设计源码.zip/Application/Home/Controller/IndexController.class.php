<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends SessionController {
    public function index(){
        $mail='1294404454@qq.com';
        $title='这只是一个测试用的邮件';
        $content='这是正文的内容 不要当垃圾邮件处理吧';
        if(SendMail($mail,$title,$content))
                $this->success('发送成功！');
            else
                $this->error('发送失败');

    }

    public function lst(){
    	$user=M('User');
    	$id=session('id');
    	$users=$user->find($id);
        $content=M('Content');
        $map['id']=session('id');
        $contents=$content->join('system_user ON system_content.uid = system_user.id')->where($map)->select();
        $count=count($contents);
        $this->assign('count',$count);
    	$this->assign('data',$users);
    	$this->display('lst');
    }
}
<?php
namespace Home\Controller;
use Think\Controller;
class LogoutController extends Controller {
   public function logout(){
      session(null);
      if(session('flag') !== 3){
        $this->success('退出成功',U('Login/index'));
      }
    }
}
<?php
namespace Home\Model;
use Think\Model;
class UserModel extends Model {
    protected $_validate = array(
       array('password','require','密码不能为空!'), //默认情况下用正则进行验证
       array('username','require','名称不能为空!'),
       array('email','require','邮箱不能为空!'),
       array('tel','require','手机号不能为空!'),
       array('rpassword','password','两次输入的密码不一致！',0,'confirm'),
       array('password','require','密码不能为空!',1,'regex',4),
       array('username','require','账号不能为空!',1,'regex',4),
       array('verify','check_verify','验证码错误!',1,'callback',4),
   );

    public function login(){
    	$password=$this->password;
    	$info=$this->where(array('username'=>$this->username))->find();
    	if($info){
    		if($info['password'] == $password){
    			session('id',$info['id']);
    			session('username',$info['username']);
          session('flag',3);
    			return true;
    		}else{
    			return false;
    		}
    	}else{
    		return false;
    	}
    }


    function check_verify($code, $id = ''){
    	$verify = new \Think\Verify();
    	return $verify->check($code, $id);
	}



}
<?php
namespace Home\Model;
use Think\Model;
class ContentModel extends Model {
    protected $_validate = array(
       array('contents','require','投诉内容不能为空!'), //默认情况下用正则进行验证
   );
}
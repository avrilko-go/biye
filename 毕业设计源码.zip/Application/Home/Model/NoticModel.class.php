<?php
namespace Manager\Model;
use Think\Model;
class NoticModel extends Model {
    protected $_validate = array(
       array('notics','require','公告内容不能为空!'), //默认情况下用正则进行验证
   );
}
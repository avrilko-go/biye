<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>用户注册</title>
    <link href="/Public/css/admin_login.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div class="admin_login_wrap">
    <h1>用户注册</h1>
    <div class="adming_login_border">
        <div class="admin_input">
            <form action="/index.php/Home/Reg/add" method="post">
                <ul class="admin_items">
                    <li>
                        <label for="user">用户名：</label>
                        <input type="text" name="username" value="admin" id="user" size="35" class="admin_input_style" />
                    </li>

                    <li>
                        <label for="pwd">密码：</label>
                        <input type="password" name="password" value="admin" id="pwd" size="35" class="admin_input_style" />
                    </li>

                    <li>
                        <label for="pwd">再输一次密码：</label>
                        <input type="password" name="rpassword" value="admin" id="pwd" size="35" class="admin_input_style" />
                    </li>

                    <li>
                        <label for="pwd">手机号码：</label>
                        <input type="password" name="tel" value="admin" id="pwd" size="35" class="admin_input_style" />
                    </li>

                    <li>
                        <label for="pwd">邮箱：</label>
                        <input type="password" name="email" value="admin" id="pwd" size="35" class="admin_input_style" />
                    </li>

                    <li>
                        <label for="pwd">验证码：</label>
                        <input type="password" name="verify" value="admin" id="pwd" size="35" class="admin_input_style" />
                        <div onclick='this.innerHTML="<img src=/index.php/Home/Login/verify?r="+Math.random()+"></img>"'>
                            <img src="/index.php/Home/Login/verify" width="243" height="60">
                        </div>
                    </li>

                    <li>
                        <input type="submit" tabindex="3" value="提交" class="btn btn-primary" />
                    </li>
                </ul>
            </form>
        </div>
    </div>
</div>
</body>
</html>
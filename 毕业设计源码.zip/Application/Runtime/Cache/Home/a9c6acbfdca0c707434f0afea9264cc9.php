<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/css/main.css"/>
    <script type="text/javascript" src="/Public/js/libs/modernizr.min.js"></script>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">客服经理后台</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li style="padding-left: 50px;">欢迎尊敬的客户：&nbsp;&nbsp;<?php echo session('username');?></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="/index.php/Home/Logout/logout">退出</a></li>
            </ul>
        </div>
    </div>
</div> 
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>客服经理操作</a>
                    <ul class="sub-menu">
                        <li><a href="/index.php/Home/Put/put"><i class="icon-font">&#xe008;</i>发布投诉</a></li>
                        <li><a href="/index.php/Home/Info/lst"><i class="icon-font">&#xe006;</i>个人信息管理</a></li>
                        <li><a href="/index.php/Home/Selected/lst"><i class="icon-font">&#xe004;</i>受理查看</a></li>
                        <li><a href="/index.php/Home/Notic/lst"><i class="icon-font">&#xe052;</i>查看公告</a></li>
                        
                    </ul>
                </li>
                
            </ul>
        </div>
    </div> 
    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="/index.php/Home/Index/index">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">客户信息管理</span></div>
        </div>
        
        <div class="result-wrap">
            <form name="myform" id="myform" method="post">
                <div class="result-title">
                </div>
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th>用户名</th>
                            <th>密码</th>
                            <th>手机号码</th>
                            <th>邮箱</th>
                            <th>注册时间</th>
                            <th>操作</th>
                        </tr>
                        <tr>
                            <td><?php echo ($datas["username"]); ?></td>
                            <td><?php echo ($datas["password"]); ?></td>
                            <td><?php echo ($datas["tel"]); ?></td>
                            <td><?php echo ($datas["email"]); ?></td>
                            <td><?php echo (date("Y-m-d",$datas['utime'])); ?>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<?php echo (date("H:i:s",$datas['utime'])); ?></td>
                            <td>
                                <a class="link-update" href="/index.php/Home/Info/edit/id/<?php echo ($datas["id"]); ?>">修改</a>
                            </td>
                        </tr>
                        
                    </table>
                </div>
            </form>
        </div>
    </div>
    <!--/main-->
</div>
</body>
</html>
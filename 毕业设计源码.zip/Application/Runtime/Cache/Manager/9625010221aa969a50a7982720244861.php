<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/css/main.css"/>
    <script type="text/javascript" src="/Public/js/libs/modernizr.min.js"></script>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">客服经理后台</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li style="padding-left: 50px;">欢迎尊敬的客服经理：&nbsp;&nbsp;<?php echo session('mname');?></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="/index.php/Manager/Manager/edit">修改客服经理信息</a></li>
                <li><a href="/index.php/Manager/Logout/logout">退出</a></li>
            </ul>
        </div>
    </div>
</div> 
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>客服经理操作</a>
                    <ul class="sub-menu">
                        <li><a href="/index.php/Manager/Lst/lst"><i class="icon-font">&#xe008;</i>未处理信息管理</a></li>
                        <li><a href="/index.php/Manager/Info/lst"><i class="icon-font">&#xe006;</i>客户信息管理</a></li>
                        <li><a href="/index.php/Manager/Selected/lst"><i class="icon-font">&#xe004;</i>已受理查看</a></li>
                        <li><a href="/index.php/Manager/Notic/lst"><i class="icon-font">&#xe052;</i>公告管理</a></li>
                        
                    </ul>
                </li>
                
            </ul>
        </div>
    </div> 
    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="/index.php/Manager/Index/index">首页</a><span class="crumb-step">&gt;</span><a class="crumb-name" href="/index.php/Manager/Notic/lst">公告管理</a><span class="crumb-step">&gt;</span><span>发布公告</span></div>
        </div>
        <div class="result-wrap">
            <div class="result-content">
                <form action="" method="post" id="myform" name="myform">
                    <table class="insert-tab" width="100%">
                        <tbody>                          

                            <tr>
                                <th><i class="require-red">*</i>公告内容：</th>
                                <td>
                                    <textarea style="width: 550px; height: 180px;" name="notics"></textarea>
                                </td>
                            </tr>
                            
                            <tr>
                                <th></th>
                                <td>
                                    <input class="btn btn-primary btn6 mr10" value="提交" type="submit">
                                    <input class="btn btn6" onclick="history.go(-1)" value="返回" type="button">
                                </td>
                            </tr>
                        </tbody></table>
                </form>
            </div>
        </div>

    </div>
    <!--/main-->
</div>
</body>
</html>
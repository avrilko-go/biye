<?php if (!defined('THINK_PATH')) exit();?><!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>后台管理</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/common.css"/>
    <link rel="stylesheet" type="text/css" href="/Public/css/main.css"/>
    <script type="text/javascript" src="/Public/js/libs/modernizr.min.js"></script>
</head>
<body>
<div class="topbar-wrap white">
    <div class="topbar-inner clearfix">
        <div class="topbar-logo-wrap clearfix">
            <h1 class="topbar-logo none"><a href="index.html" class="navbar-brand">客服经理后台</a></h1>
            <ul class="navbar-list clearfix">
                <li><a class="on" href="index.html">首页</a></li>
                <li style="padding-left: 50px;">欢迎尊敬的客服经理：&nbsp;&nbsp;<?php echo session('mname');?></li>
            </ul>
        </div>
        <div class="top-info-wrap">
            <ul class="top-info-list clearfix">
                <li><a href="/index.php/Manager/Manager/edit">修改客服经理信息</a></li>
                <li><a href="/index.php/Manager/Logout/logout">退出</a></li>
            </ul>
        </div>
    </div>
</div> 
<div class="container clearfix">
    <div class="sidebar-wrap">
        <div class="sidebar-title">
            <h1>菜单</h1>
        </div>
        <div class="sidebar-content">
            <ul class="sidebar-list">
                <li>
                    <a href="#"><i class="icon-font">&#xe003;</i>客服经理操作</a>
                    <ul class="sub-menu">
                        <li><a href="/index.php/Manager/Lst/lst"><i class="icon-font">&#xe008;</i>未处理信息管理</a></li>
                        <li><a href="/index.php/Manager/Info/lst"><i class="icon-font">&#xe006;</i>客户信息管理</a></li>
                        <li><a href="/index.php/Manager/Selected/lst"><i class="icon-font">&#xe004;</i>已受理查看</a></li>
                        <li><a href="/index.php/Manager/Notic/lst"><i class="icon-font">&#xe052;</i>公告管理</a></li>
                        
                    </ul>
                </li>
                
            </ul>
        </div>
    </div> 
    <!--/sidebar-->
    <div class="main-wrap">

        <div class="crumb-wrap">
            <div class="crumb-list"><i class="icon-font"></i><a href="/index.php/Manager/Index/index">首页</a><span class="crumb-step">&gt;</span><span class="crumb-name">未处理反馈信息管理</span></div>
        </div>
        
        <div class="result-wrap">
            <form name="myform" id="myform" method="post">
                <div class="result-title">
                </div>
                <div class="result-content">
                    <table class="result-tab" width="100%">
                        <tr>
                            <th>用户名</th>
                            <th>反馈内容</th>
                            <th>反馈时间</th>
                            <th>操作</th>
                        </tr>
                        <?php if(is_array($data)): foreach($data as $key=>$datas): if($datas['gid'] == $_SESSION['mid']): ?><tr>
                            <td><?php echo ($datas["username"]); ?></td>
                            <td><?php echo ($datas["contents"]); ?></td>
                            <td><?php echo (date("Y-m-d",$datas['times'])); ?>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<?php echo (date("H:i:s",$datas['times'])); ?></td>
                            <td>    
                                <a class="link-del"  href="/index.php/Manager/Selected/reply/cid/<?php echo ($datas["cid"]); ?>">回复反馈</a>
                                <a class="link-del" onclick="return confirm('确认删除？')" href="/index.php/Manager/Selected/del/cid/<?php echo ($datas["cid"]); ?>">删除</a>
                            </td>    
                        </tr><?php endif; endforeach; endif; ?>
                        
                    </table>
                    <div class="list-page"><?php echo ($page); ?></div>
                </div>
            </form>
        </div>
    </div>
    <!--/main-->
</div>
</body>
</html>